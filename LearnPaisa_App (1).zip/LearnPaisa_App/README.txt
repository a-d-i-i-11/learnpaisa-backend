╔══════════════════════════════════════════════════════════╗
║           LEARNPAISA — SKILL GAMING APP                  ║
║           Built with ❤️ by Claude for Amir Bhai          ║
╚══════════════════════════════════════════════════════════╝

📁 FILES IN THIS FOLDER:
━━━━━━━━━━━━━━━━━━━━━━━━
01_home.html         → Landing Page (show to users)
02_dashboard.html    → Player Dashboard
03_games_lobby.html  → Games Lobby (Ludo, Chess, Carrom, Task)
04_wallet.html       → Wallet (Add Money / Withdraw)
05_profile.html      → Player Profile & Achievements
06_admin_panel.html  → 👑 Admin Panel (YOUR secret screen!)

🚀 HOW TO OPEN:
━━━━━━━━━━━━━━━
Just double-click any .html file to open in your browser!
No installation needed. Works on Chrome, Firefox, Edge.

🌐 HOW TO PUT ONLINE (FREE!):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. Go to https://netlify.com
2. Sign up FREE with your Gmail
3. Drag this whole folder onto Netlify
4. Your app is LIVE in 30 seconds! 🎉
   You'll get a free link like: learnpaisa.netlify.app

💡 NEXT STEPS TO GO LIVE:
━━━━━━━━━━━━━━━━━━━━━━━━━
Step 1: Deploy on Netlify (free) → Done in 5 min!
Step 2: Buy domain learnpaisa.com on GoDaddy (~₹1,000)
Step 3: Connect domain to Netlify (free guide available)
Step 4: Add real backend (Claude will build this next!)
Step 5: Connect Razorpay for real payments
Step 6: Launch in Kashmir → Expand India-wide! 🇮🇳

🎮 GAMES PLANNED:
━━━━━━━━━━━━━━━━━
✅ Ludo King      - 1v1 / 4 Player
✅ Chess Battle   - 1v1 Timed
✅ Carrom Club    - 1v1 / 2v2
✅ Live Task      - Speed Challenge

💰 REVENUE MODEL:
━━━━━━━━━━━━━━━━━
Entry Fee × 2 Players = Prize Pool
Winner gets 85% → Platform keeps 15%
1,000 matches/day = ₹15,000/day revenue!

📞 CONTACT / SUPPORT:
━━━━━━━━━━━━━━━━━━━━━
Built by Claude AI for Amir Bhai — Kashmir, India 🏔️
Keep grinding bro, this is going to be BIG! 🔥

